//===== Changelog ============================================
//=  - 0.2 Init. S2.17 [David]
//============================================================



/**
 * @summary (Tiene pinta de ser una clase estatica donde
 * tiene diferentes colores/valores para cambiar el
 * color/intensidad de la iluminacion)
 * @see {@link http://localhost:3000/pdf/S2.pdf#page=17 | S2.17}
 * @author David
 * @version 0.2
 */
export class TColor {
   
}
