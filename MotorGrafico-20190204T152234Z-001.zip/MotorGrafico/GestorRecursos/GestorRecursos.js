"use strict";

//CLASE RECURSO DE LA QUE HEDERAN EL RESTO
class TRecurso{
    constructor(a){
    	this.nombre = a;
    }
    get GetRecursoNombre(){
    	return this.nombre;
    }
    SetNombre(a){
    	this.nombre = a;
    }
}

//RECURSO MALLA
class TRecursoMalla extends TRecurso {
	constructor(a){
    	super(a);
    	this.normales=[];
    	this.vertices=[]; //Un array con todas las posiciones  
    	this.uvs=[];
    	this.faces=[];
    	this.colors=[];    	
		this.metadata;
    }  

    cargarFichero(){	
		let url = "./GestorRecursos/mallas/" + this.nombre;
		var that = this;
		let p = new XMLHttpRequest();
			p.open('GET', url, true);
			p.responseType = 'text';

			p.onload = function () {
			    if (p.readyState === p.DONE) {
			        if (p.status === 200) {
			            that.actualizarValores(JSON.parse(p.responseText));			            
			        }
			    }
			};
			p.send(null);
    }  

    actualizarValores(j){
    	this.normales = j.normals;
        this.vertices = j.vertices;
        this.uvs	  = j.uvs;
    	this.faces    = j.faces;
    	this.colors   = j.colors;
    	this.metadata = j.metadata;
    }

    draw(){
    	console.log("Entrando al draw() de TRMalla");
    }
}

//RECURSO MATERIAL
class TRecursoMaterial extends TRecurso {
	constructor(a){
    	super(a);
 		this.colorSpecular=[0,0,0];
        this.shading="";
        this.doubleSided=false;
        this.depthTest=false;
        this.wireframe=false;
        this.vertexColors=false;
        this.DbgColor=0;
        this.colorEmissive=[0,0,0];
        this.blending=0;
        this.depthWrite=false;
        this.visible=false;
        this.specularCoef=0;
        this.opacity=0;
        this.DbgName="";
        this.DbgIndex=0;
        this.transparent=false;
        this.colorDiffuse=[0,0,0];
    }

    cargarFichero(){
		let url = "./GestorRecursos/materiales/" + this.nombre;
		var that = this;
		let p = new XMLHttpRequest();
			p.open('GET', url, true);
			p.responseType = 'text';

			p.onload = function () {
			    if (p.readyState === p.DONE) {
			        if (p.status === 200) {
			            that.actualizarValores(JSON.parse(p.responseText));			            
			        }
			    }
			};
			p.send(null);
    }

    actualizarValores(j){
		this.colorSpecular	= j.colorSpecular;
		this.shading		= j.shading;
		this.doubleSided	= j.doubleSided;
		this.depthTest		= j.depthTest;
		this.wireframe		= j.wireframe;
		this.vertexColors	= j.vertexColors;
		this.DbgColor		= j.DbgColor;
		this.colorEmissive	= j.colorEmissive;
		this.blending		= j.blending;
		this.depthWrite		= j.depthWrite;
		this.visible		= j.visible;
		this.specularCoef	= j.specularCoef;
		this.opacity		= j.opacity;
		this.DbgName		= j.DbgName;
		this.DbgIndex		= j.DbgIndex;
		this.transparent	= j.transparent;
		this.colorDiffuse	= j.colorDiffuse;
    }
}

//RECURSO TEXTURA
class TRecursoTextura extends TRecurso {
    constructor(a){
    	super(a);
    	this.textura = new Image();
    }
    cargarFichero(){
    	var c = false;    	
    	try{
    		this.textura.src = './texturas/'+this.nombre;
    		c = true;
    	}
    	catch(e){ console.log(e); }
    	return c;
    }
}



/************************/
//    CLASE PRINCIPAL
/************************/
class TGestorRecursos{
	constructor () {
		this.arrayRecursos = [];
		this.arrayIndice = [];
	}

	TRMalla(a){
		//se busca en el indice de nombres si existe el recurso
		var p = this.arrayIndice.indexOf(a);
		var malla = this.arrayRecursos[p];

		//si existe se devuelve, si no se crea
		if(malla == null || malla == undefined){

			//se verifica que sea un string y el formato correcto
			if(this.verificarFormato(a,1)){

				//Creamos el recurso y hacemos push
				malla = new TRecursoMalla(a);
				malla.cargarFichero();
				this.arrayRecursos.push(malla);
				this.arrayIndice.push(a);													
			}
		}
		return malla;
	}

	TRMaterial(a){
		var p = this.arrayIndice.indexOf(a);
		var material = this.arrayRecursos[p];
		if(material == null || material == undefined){
			if(this.verificarFormato(a,1)){
				material = new TRecursoMaterial(a);
				material.cargarFichero();
				this.arrayRecursos.push(material);
				this.arrayIndice.push(a);												
			}
		}
		return material;		
	}

	TRTextura(a){
		var p = this.arrayIndice.indexOf(a);
		var textura = this.arrayRecursos[p];
		if(textura == null || textura == undefined){
			if(this.verificarFormato(a,2)){
				textura = new TRecursoTextura(a);
				textura.cargarFichero();
				this.arrayRecursos.push(textura);
				this.arrayIndice.push(a);											
			}
		}
		return textura;
	}

	//comprueba que el nombre sea string y que el formato es el correcto
	verificarFormato(a,i){
		var res = false;    	
    	if(typeof(a) == 'string'){    		
    		var f = a.split('.');
    		if(i==1 && (f[f.length-1]).toLowerCase() == "json"){ res = true; }
    		else if(i==2 && (
    			(f[f.length-1]).toLowerCase() == "jpg" ||
    			(f[f.length-1]).toLowerCase() == "jpeg" ||
    			(f[f.length-1]).toLowerCase() == "png"
    			)){ res = true; }
    		else {
    			console.log("Error: El formato no es correcto (OBJ para objetos 3D, MTL para materiales, JPG para texturas.");
    		}
    	}
    	else{
    		console.log("Error: El nombre pasado no es un String.");
    	}
    	return res;
	}

	//elimina un recurso del arrayRecursos
	eliminarRecurso(a){
		var res = false;
		var p = this.arrayIndice.indexOf(a);
		if(p > -1){
			this.arrayRecursos.splice(p);
			this.arrayIndice.splice(p);
			res = true;
		} 
		return res;
	}

	//Mostrar todos los recursos para probar codigo 
	//TODO: eliminar cuando no se necesite
	recursos(){
		for(var i = 0; i<this.arrayRecursos.length; i++){
			console.log("Recurso " + i + ":");
			console.log(this.arrayRecursos[i]);
		}		
	}
}


/************************/
//    PRUEBAS CODIGO
/************************/

var Gestor = new TGestorRecursos();

// console.log(Gestor.TRMaterial("material.json"));

// console.log(Gestor.TRMalla("icosphereMaterial.json"));

// Gestor.recursos();